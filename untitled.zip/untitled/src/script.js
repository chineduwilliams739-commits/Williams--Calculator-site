javascript
function calculate() {

  let num1 = Number(document.getElementById("num1").value);

  let num2 = Number(document.getElementById("num2").value);

  let num3 = Number(document.getElementById("num3").value);

  let operation = document.getElementById("opperation").value;

  let result;

  if (operation == "+") {

    result = num1 + num2 + num3;

  } else if (operation == "-") {

    result = num1 - num2 - num3;

  } else if (operation == "*") {

    result = num1 * num2 * num3;

  } else if (operation == "/") {

    if (num2 === 0 || num3 === 0) {

      result = "Cannot divide by zero";

    } else {

      result = num1 / num2 / num3;

    }

  } else {

    result = "Invalid operation";

  }

  document.getElementById("result").innerText = "Result: " + result;

}